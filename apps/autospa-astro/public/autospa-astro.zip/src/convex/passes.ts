import { getAuthUserId } from "@convex-dev/auth/server";
import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

/** Lista los bonos activos del usuario (con lavados restantes) */
export const myPasses = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return [];
    const all = await ctx.db
      .query("passes")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    return all.sort((a, b) => b.purchasedAt - a.purchasedAt);
  },
});

/** Compra un bono de lavados (precio calculado en el servidor) */
export const purchase = mutation({
  args: { passType: v.union(v.literal("complete4"), v.literal("premium2")) },
  handler: async (ctx, { passType }) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("Inicia sesión para comprar un bono");

    // Precio SIEMPRE en el servidor, nunca desde el cliente
    const catalog: Record<
      string,
      { serviceId: string; washesTotal: number; pricePaid: number }
    > = {
      complete4: { serviceId: "complete", washesTotal: 4, pricePaid: 119 },
      premium2: { serviceId: "premium", washesTotal: 2, pricePaid: 204 },
    };
    const def = catalog[passType];
    if (!def) throw new Error("Tipo de bono no válido");

    return await ctx.db.insert("passes", {
      userId,
      serviceId: def.serviceId,
      washesTotal: def.washesTotal,
      washesUsed: 0,
      pricePaid: def.pricePaid,
      purchasedAt: Date.now(),
    });
  },
});
