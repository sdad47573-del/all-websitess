import { getAuthUserId } from "@convex-dev/auth/server";
import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  for (let i = 0; i < 8; i++) {
    code += chars[bytes[i] % chars.length];
    if (i === 3) code += "-";
  }
  return `AUTO-${code}`;
}

/** Crea un bono regalo con código único (el pago se realiza en el taller) */
export const purchase = mutation({
  args: { amount: v.number() },
  handler: async (ctx, { amount }) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("Inicia sesión para comprar un bono regalo");

    const VALID = [25, 50, 100];
    if (!VALID.includes(amount)) throw new Error("Importe no válido");

    const code = generateCode();
    await ctx.db.insert("gifts", {
      code,
      amount,
      buyerUserId: userId,
      status: "active",
      createdAt: Date.now(),
    });
    return { code, amount };
  },
});

/** Bonos regalo comprados por el usuario (para reenviar el código) */
export const myGifts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return [];
    const all = await ctx.db.query("gifts").collect();
    return all
      .filter((g) => g.buyerUserId === userId)
      .sort((a, b) => b.createdAt - a.createdAt);
  },
});

/**
 * Valida un código de bono regalo para un usuario.
 * Devuelve el importe disponible o error si no es utilizable por él.
 */
export const validate = query({
  args: { code: v.string() },
  handler: async (ctx, { code }) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return { valid: false as const, reason: "Inicia sesión" };

    const gift = await ctx.db
      .query("gifts")
      .withIndex("by_code", (q) => q.eq("code", code.trim().toUpperCase()))
      .first();
    if (!gift) return { valid: false as const, reason: "Código no encontrado" };
    if (gift.status === "redeemed") {
      return { valid: false as const, reason: "Este bono ya ha sido canjeado" };
    }
    if (gift.buyerUserId === userId) {
      return {
        valid: false as const,
        reason: "No puedes canjear tu propio bono regalo",
      };
    }
    return { valid: true as const, amount: gift.amount, code: gift.code };
  },
});
