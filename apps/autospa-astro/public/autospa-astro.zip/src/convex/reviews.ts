import { getAuthUserId } from "@convex-dev/auth/server";
import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

/** Reseñas verificadas (con comentario) para mostrar en la landing */
export const listVerified = query({
  args: {},
  handler: async (ctx) => {
    const all = await ctx.db.query("reviews").collect();
    const withComment = all
      .filter((r) => (r.comment ?? "").trim().length > 0)
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 6);

    // Adjunta el nombre del autor (primera palabra, por privacidad)
    return Promise.all(
      withComment.map(async (r) => {
        const user = await ctx.db.get(r.userId);
        const name = user?.name ?? "Cliente";
        return {
          _id: r._id,
          author: name.split(" ")[0],
          rating: r.rating,
          comment: r.comment!,
          createdAt: r.createdAt,
        };
      }),
    );
  },
});

/** Media y total de valoraciones para el panel admin */
export const summary = query({
  args: {},
  handler: async (ctx) => {
    const all = await ctx.db.query("reviews").collect();
    if (all.length === 0) return { avg: 0, total: 0 };
    const avg = all.reduce((s, r) => s + r.rating, 0) / all.length;
    return { avg: Math.round(avg * 10) / 10, total: all.length };
  },
});

/** Crea una reseña para un servicio finalizado del propio usuario */
export const create = mutation({
  args: {
    bookingId: v.id("bookings"),
    rating: v.number(),
    comment: v.optional(v.string()),
  },
  handler: async (ctx, { bookingId, rating, comment }) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("No autenticado");

    if (rating < 1 || rating > 5) throw new Error("Valoración entre 1 y 5");

    const booking = await ctx.db.get(bookingId);
    if (!booking) throw new Error("Reserva no encontrada");
    if (booking.userId !== userId) throw new Error("No es tu reserva");
    if (booking.status !== "done") {
      throw new Error(
        "Solo puedes valorar servicios finalizados (reseñas verificadas)",
      );
    }

    // Una reseña por reserva
    const existing = await ctx.db
      .query("reviews")
      .withIndex("by_booking", (q) => q.eq("bookingId", bookingId))
      .first();
    if (existing) throw new Error("Ya has valorado este servicio");

    await ctx.db.insert("reviews", {
      userId,
      bookingId,
      rating,
      comment: comment?.trim() || undefined,
      createdAt: Date.now(),
    });
  },
});
