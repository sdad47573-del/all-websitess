import { getAuthUserId } from "@convex-dev/auth/server";
import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { ROLES } from "./schema";

/** Horarios disponibles por día en el centro */
export const TIME_SLOTS = ["09:00", "11:00", "13:00", "16:00", "18:00"];

/** Máximo de coches por franja horaria (plazas del box) */
const SLOTS_CAPACITY = 2;

const serviceValidator = v.union(
  v.literal("express"),
  v.literal("complete"),
  v.literal("premium"),
  v.literal("ceramic"),
);

const vehicleValidator = v.union(
  v.literal("small"),
  v.literal("sedan"),
  v.literal("suv"),
  v.literal("van"),
);

const statusValidator = v.union(
  v.literal("pending"),
  v.literal("confirmed"),
  v.literal("done"),
  v.literal("cancelled"),
);

async function requireAdmin(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (userId === null) throw new Error("No autenticado");
  const user = await ctx.db.get(userId);
  if (user?.role !== ROLES.ADMIN) throw new Error("Solo administradores");
  return userId;
}

/** Catálogos de precios — SIEMPRE en el servidor, nunca desde el cliente */
const BASE_PRICES: Record<string, number> = {
  express: 15,
  complete: 35,
  premium: 120,
  ceramic: 350,
};
const VEHICLE_MULT: Record<string, number> = {
  small: 0.9,
  sedan: 1,
  suv: 1.2,
  van: 1.4,
};
const EXTRA_PRICES: Record<string, number> = {
  ozono: 12,
  motor: 20,
  faros: 25,
  cuero: 30,
};
export const PROMO_CODE = "AUTO10";
const PROMO_DISCOUNT_PCT = 10;

/**
 * Precio autoritativo: base × vehículo + extras, con promo o bono.
 */
async function computePrice(
  ctx: any,
  userId: any,
  serviceId: string,
  vehicleType: string,
  extras: string[],
  promoCode?: string,
  passId?: any,
  pickup?: boolean,
  giftCode?: string,
): Promise<{ price: number; discount: number }> {
  const base = BASE_PRICES[serviceId] ?? 0;
  const mult = VEHICLE_MULT[vehicleType] ?? 1;
  const extrasTotal = extras.reduce(
    (sum, e) => sum + (EXTRA_PRICES[e] ?? 0),
    0,
  );
  const washValue = Math.round(base * mult);
  let price = washValue + extrasTotal;
  let discount = 0;

  // Bono activo para ese servicio: el lavado va gratis y se consume 1 lavado
  if (passId) {
    const pass = await ctx.db.get(passId);
    if (
      pass &&
      pass.userId === userId &&
      pass.washesUsed < pass.washesTotal &&
      pass.serviceId === serviceId
    ) {
      price = Math.max(0, price - washValue);
      discount = 100;
    }
  }

  // Recogida a domicilio (+15€)
  if (pickup) {
    price += 15;
  }

  // Bono regalo: descuenta su importe (la validación completa se hace en create)
  if (giftCode) {
    const gift = await ctx.db
      .query("gifts")
      .withIndex("by_code", (q: any) => q.eq("code", giftCode))
      .first();
    if (gift && gift.status === "active" && gift.buyerUserId !== userId) {
      price = Math.max(0, price - gift.amount);
      discount = 100;
    }
  }

  // Promo -10% primera reserva online (acumulable solo si no hay bono)
  if (promoCode === PROMO_CODE && discount === 0) {
    discount = PROMO_DISCOUNT_PCT;
    price = Math.round(price * 0.9);
  }

  return { price, discount };
}

/** Franjas ocupadas de un día: [{ timeSlot, taken, free }] */
export const dayAvailability = query({
  args: { date: v.string() },
  handler: async (ctx, { date }) => {
    const bookings = await ctx.db
      .query("bookings")
      .withIndex("by_date", (q) => q.eq("date", date))
      .collect();
    const active = bookings.filter((b) => b.status !== "cancelled");
    return TIME_SLOTS.map((slot) => ({
      timeSlot: slot,
      taken: active.filter((b) => b.timeSlot === slot).length,
      free:
        SLOTS_CAPACITY - active.filter((b) => b.timeSlot === slot).length > 0,
    }));
  },
});

/** Historial de reservas del usuario autenticado */
export const myBookings = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return [];
    return await ctx.db
      .query("bookings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
  },
});

/** Todas las reservas (solo admin) */
export const allBookings = query({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    return await ctx.db.query("bookings").collect();
  },
});

/** Crea una reserva validando slot, horario y datos del vehículo */
export const create = mutation({
  args: {
    serviceId: serviceValidator,
    vehicleType: vehicleValidator,
    vehiclePlate: v.optional(v.string()),
    date: v.string(),
    timeSlot: v.string(),
    notes: v.optional(v.string()),
    extras: v.optional(v.array(v.string())),
    promoCode: v.optional(v.string()),
    usePassId: v.optional(v.id("passes")),
    pickup: v.optional(v.boolean()),
    giftCode: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("Inicia sesión para reservar");

    if (!TIME_SLOTS.includes(args.timeSlot)) {
      throw new Error("Franja horaria no válida");
    }
    const today = new Date();
    const todayStr = today.toISOString().slice(0, 10);
    if (args.date < todayStr) {
      throw new Error("No puedes reservar en fechas pasadas");
    }
    const daysAhead = Math.floor(
      (new Date(args.date).getTime() - today.getTime()) / 86400000,
    );
    if (daysAhead > 60) {
      throw new Error("Solo se puede reservar con 60 días de antelación");
    }

    const sameDay = await ctx.db
      .query("bookings")
      .withIndex("by_date", (q) => q.eq("date", args.date))
      .collect();
    const taken = sameDay.filter(
      (b) => b.timeSlot === args.timeSlot && b.status !== "cancelled",
    ).length;
    if (taken >= SLOTS_CAPACITY) {
      throw new Error("Esa franja horaria está completa. Elige otra.");
    }

    // Si usa bono: valida antes de calcular precio
    if (args.usePassId) {
      const pass = await ctx.db.get(args.usePassId);
      if (!pass || pass.userId !== userId) throw new Error("Bono no válido");
      if (pass.washesUsed >= pass.washesTotal) {
        throw new Error("Tu bono no tiene lavados restantes");
      }
      if (pass.serviceId !== args.serviceId) {
        throw new Error("Este bono es para otro tipo de servicio");
      }
    }

    // Valida el bono regalo (no puede canjearlo el comprador, ni reutilizado)
    if (args.giftCode) {
      const gift = await ctx.db
        .query("gifts")
        .withIndex("by_code", (q) => q.eq("code", args.giftCode!.trim().toUpperCase()))
        .first();
      if (!gift) throw new Error("Código de bono regalo no válido");
      if (gift.status === "redeemed") {
        throw new Error("Este bono regalo ya ha sido canjeado");
      }
      if (gift.buyerUserId === userId) {
        throw new Error("No puedes canjear tu propio bono regalo");
      }
    }

    // Precio autoritativo en el servidor
    const { price, discount } = await computePrice(
      ctx,
      userId,
      args.serviceId,
      args.vehicleType,
      args.extras ?? [],
      args.promoCode,
      args.usePassId,
      args.pickup,
      args.giftCode,
    );

    // Consume un lavado del bono
    if (args.usePassId) {
      const pass = await ctx.db.get(args.usePassId);
      if (pass) {
        await ctx.db.patch(pass._id, { washesUsed: pass.washesUsed + 1 });
      }
    }

    // Marca el bono regalo como canjeado
    if (args.giftCode) {
      const gift = await ctx.db
        .query("gifts")
        .withIndex("by_code", (q) => q.eq("code", args.giftCode!.trim().toUpperCase()))
        .first();
      if (gift) {
        await ctx.db.patch(gift._id, {
          status: "redeemed",
          redeemedBy: userId,
          redeemedAt: Date.now(),
        });
      }
    }

    const bookingId = await ctx.db.insert("bookings", {
      userId,
      serviceId: args.serviceId,
      vehicleType: args.vehicleType,
      vehiclePlate: args.vehiclePlate,
      date: args.date,
      timeSlot: args.timeSlot,
      price,
      status: "pending",
      notes: args.notes,
      extras: args.extras,
      discount,
      usedPassId: args.usePassId,
      pickup: args.pickup,
      giftCode: args.giftCode,
    });
    return bookingId;
  },
});

/** El cliente cancela una reserva propia (si no está finalizada) */
export const cancel = mutation({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, { bookingId }) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("No autenticado");
    const booking = await ctx.db.get(bookingId);
    if (!booking) throw new Error("Reserva no encontrada");
    if (booking.userId !== userId) throw new Error("No es tu reserva");
    if (booking.status === "done") {
      throw new Error("No puedes cancelar un servicio ya finalizado");
    }
    await ctx.db.patch(bookingId, { status: "cancelled" });

    // Devuelve el lavado al bono si la reserva lo consumió
    if (booking.usedPassId) {
      const pass = await ctx.db.get(booking.usedPassId);
      if (pass && pass.washesUsed > 0) {
        await ctx.db.patch(pass._id, { washesUsed: pass.washesUsed - 1 });
      }
    }
  },
});

/** Cambio de estado por parte del taller (admin) */
export const setStatus = mutation({
  args: { bookingId: v.id("bookings"), status: statusValidator },
  handler: async (ctx, { bookingId, status }) => {
    await requireAdmin(ctx);
    await ctx.db.patch(bookingId, { status });
  },
});

/** KPIs para el panel de administración */
export const adminStats = query({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    const all = await ctx.db.query("bookings").collect();
    const today = new Date().toISOString().slice(0, 10);
    return {
      total: all.length,
      pending: all.filter((b) => b.status === "pending").length,
      confirmed: all.filter((b) => b.status === "confirmed").length,
      done: all.filter((b) => b.status === "done").length,
      cancelled: all.filter((b) => b.status === "cancelled").length,
      todayCount: all.filter(
        (b) => b.date === today && b.status !== "cancelled",
      ).length,
      revenueDone: all
        .filter((b) => b.status === "done")
        .reduce((sum, b) => sum + b.price, 0),
    };
  },
});
