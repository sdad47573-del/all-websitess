import { getAuthUserId } from "@convex-dev/auth/server";
import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { ROLES } from "./schema";

/** Envía el formulario de contacto (público) */
export const send = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    body: v.string(),
  },
  handler: async (ctx, { name, email, phone, body }) => {
    if (!name.trim()) throw new Error("Indica tu nombre");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      throw new Error("Email no válido");
    }
    if (body.trim().length < 10) {
      throw new Error("Cuéntanos algo más (mínimo 10 caracteres)");
    }
    return await ctx.db.insert("messages", {
      name: name.trim(),
      email: email.trim(),
      phone: phone?.trim(),
      body: body.trim(),
      status: "new",
      createdAt: Date.now(),
    });
  },
});

/** Bandeja de mensajes (solo admin) */
export const listForAdmin = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return [];
    const user = await ctx.db.get(userId);
    if (user?.role !== ROLES.ADMIN) return [];
    return await ctx.db.query("messages").collect();
  },
});

/** Marca un mensaje como leído (admin) */
export const markRead = mutation({
  args: { messageId: v.id("messages") },
  handler: async (ctx, { messageId }) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("No autenticado");
    const user = await ctx.db.get(userId);
    if (user?.role !== ROLES.ADMIN) throw new Error("Solo administradores");
    await ctx.db.patch(messageId, { status: "read" });
  },
});
