import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { Infer, v } from "convex/values";

// default user roles. can add / remove based on the project as needed
export const ROLES = {
  ADMIN: "admin",
  USER: "user",
  MEMBER: "member",
} as const;

export const roleValidator = v.union(
  v.literal(ROLES.ADMIN),
  v.literal(ROLES.USER),
  v.literal(ROLES.MEMBER),
);
export type Role = Infer<typeof roleValidator>;

const schema = defineSchema(
  {
    // default auth tables using convex auth.
    ...authTables, // do not remove or modify

    // the users table is the default users table that is brought in by the authTables
    users: defineTable({
      name: v.optional(v.string()), // name of the user. do not remove
      image: v.optional(v.string()), // image of the user. do not remove
      email: v.optional(v.string()), // email of the user. do not remove
      emailVerificationTime: v.optional(v.number()), // email verification time. do not remove
      isAnonymous: v.optional(v.boolean()), // is the user anonymous. do not remove

      role: v.optional(roleValidator), // role of the user. do not remove
    }).index("email", ["email"]), // index for the email. do not remove or modify

    // Reservas de servicios (lavado y detailing)
    bookings: defineTable({
      userId: v.id("users"),
      serviceId: v.string(), // "express" | "complete" | "premium" | "ceramic"
      vehicleType: v.string(), // "small" | "sedan" | "suv" | "van"
      vehiclePlate: v.optional(v.string()),
      date: v.string(), // "YYYY-MM-DD"
      timeSlot: v.string(), // "09:00" | "11:00" ...
      price: v.number(),
      status: v.string(), // "pending" | "confirmed" | "done" | "cancelled"
      notes: v.optional(v.string()),
      extras: v.optional(v.array(v.string())), // ids de servicios extra
      discount: v.optional(v.number()), // % aplicado (promo o bono)
      usedPassId: v.optional(v.id("passes")), // bono consumido (si aplica)
      pickup: v.optional(v.boolean()), // recogida a domicilio solicitada
      giftCode: v.optional(v.string()), // código de bono regalo usado
    })
      .index("by_user", ["userId"])
      .index("by_date", ["date"])
      .index("by_status", ["status"]),

    // Mensajes del formulario de contacto de la landing
    messages: defineTable({
      name: v.string(),
      email: v.string(),
      phone: v.optional(v.string()),
      body: v.string(),
      status: v.string(), // "new" | "read"
      createdAt: v.number(),
    }).index("by_status", ["status"]),

    // Bonos/abonos de lavados (ej: 4 lavados completos con descuento)
    passes: defineTable({
      userId: v.id("users"),
      serviceId: v.string(), // servicio incluido en el bono
      washesTotal: v.number(),
      washesUsed: v.number(),
      pricePaid: v.number(),
      purchasedAt: v.number(),
    }).index("by_user", ["userId"]),

    // Reseñas verificadas de clientes con servicio finalizado
    reviews: defineTable({
      userId: v.id("users"),
      bookingId: v.id("bookings"),
      rating: v.number(), // 1..5
      comment: v.optional(v.string()),
      createdAt: v.number(),
    })
      .index("by_user", ["userId"])
      .index("by_booking", ["bookingId"]),

    // Bonos regalo: compra un código y lo canjea otra persona
    gifts: defineTable({
      code: v.string(),
      amount: v.number(), // importe del bono en €
      buyerUserId: v.id("users"),
      status: v.string(), // "active" | "redeemed"
      createdAt: v.number(),
      redeemedBy: v.optional(v.id("users")),
      redeemedAt: v.optional(v.number()),
    }).index("by_code", ["code"]),
  },
  {
    schemaValidation: false,
  },
);

export default schema;
